// test/taxi.test.js — Unit tests for src/taxi.js (Lab Task 04)
// Style: Arrange – Act – Assert. Every expected value is worked out by hand
// from the written rule (shown in the comment above each assertion).

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import {
  fareForRide,
  totalFare,
  applyPeakSurcharge,
  waitingCharge,
  rideSummary,
  totalDistance,
} from '../src/taxi.js';

describe('R1 - fareForRide', () => {
  test('multiplies distance by rate for a whole-number fare', () => {
    // Arrange
    const distanceKm = 10;
    const ratePerKm = 25;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 10 x 25 = 250
    assert.strictEqual(result, 250);
  });

  test('rounds a fare down when the fraction is below .5', () => {
    // Arrange
    const distanceKm = 3.7;
    const ratePerKm = 12;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 3.7 x 12 = 44.4 -> nearest rupee = 44
    assert.strictEqual(result, 44);
  });

  test('rounds a fare up when the fraction is above .5', () => {
    // Arrange
    const distanceKm = 3.8;
    const ratePerKm = 12;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 3.8 x 12 = 45.6 -> nearest rupee = 46
    assert.strictEqual(result, 46);
  });

  test('returns 0 for a ride of 0 km', () => {
    // Arrange
    const distanceKm = 0;
    const ratePerKm = 30;
    // Act
    const result = fareForRide(distanceKm, ratePerKm);
    // Assert: 0 x 30 = 0
    assert.strictEqual(result, 0);
  });
});

describe('R2 - totalFare', () => {
  test('adds the fare of every ride in the list', () => {
    // Arrange
    const rides = [
      { distanceKm: 10, ratePerKm: 25 }, // 250
      { distanceKm: 3.8, ratePerKm: 12 }, // 45.6 -> 46
      { distanceKm: 8, ratePerKm: 30 }, // 240
    ];
    // Act
    const result = totalFare(rides);
    // Assert: 250 + 46 + 240 = 536
    assert.strictEqual(result, 536);
  });

  test('returns 0 for an empty list of rides', () => {
    // Arrange
    const rides = [];
    // Act
    const result = totalFare(rides);
    // Assert: no rides -> 0
    assert.strictEqual(result, 0);
  });

  test('rounds each ride (R1) before adding, not the final sum', () => {
    // Arrange
    const rides = [
      { distanceKm: 3.7, ratePerKm: 12 }, // 44.4 -> 44
      { distanceKm: 3.7, ratePerKm: 12 }, // 44.4 -> 44
    ];
    // Act
    const result = totalFare(rides);
    // Assert: 44 + 44 = 88 (rounding the raw sum 88.8 would wrongly give 89)
    assert.strictEqual(result, 88);
  });
});

describe('R3 - applyPeakSurcharge', () => {
  test('increases a round amount by the given percent', () => {
    // Arrange
    const amount = 1000;
    const percent = 20;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 1000 + 20% of 1000 = 1200
    assert.strictEqual(result, 1200);
  });

  test('rounds up to the nearest rupee when the result has a high fraction', () => {
    // Arrange
    const amount = 99;
    const percent = 15;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 99 x 1.15 = 113.85 -> 114
    assert.strictEqual(result, 114);
  });

  test('rounds down to the nearest rupee when the result has a low fraction', () => {
    // Arrange
    const amount = 333;
    const percent = 10;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 333 x 1.10 = 366.3 -> 366
    assert.strictEqual(result, 366);
  });

  test('leaves the amount unchanged when the surcharge is 0 percent', () => {
    // Arrange
    const amount = 250;
    const percent = 0;
    // Act
    const result = applyPeakSurcharge(amount, percent);
    // Assert: 250 + 0% = 250
    assert.strictEqual(result, 250);
  });
});

describe('R4 - waitingCharge', () => {
  test('is free at 4 minutes (below the 5-minute limit)', () => {
    // Arrange
    const minutes = 4;
    // Act
    const result = waitingCharge(minutes);
    // Assert: 4 <= 5 free -> 0
    assert.strictEqual(result, 0);
  });

  test('is still free at exactly 5 minutes (boundary)', () => {
    // Arrange
    const minutes = 5;
    // Act
    const result = waitingCharge(minutes);
    // Assert: first 5 minutes free -> 0
    assert.strictEqual(result, 0);
  });

  test('charges Rs 10 at 6 minutes (one minute beyond the free time)', () => {
    // Arrange
    const minutes = 6;
    // Act
    const result = waitingCharge(minutes);
    // Assert: (6 - 5) x 10 = 10
    assert.strictEqual(result, 10);
  });

  test('is free at 0 minutes of waiting', () => {
    // Arrange
    const minutes = 0;
    // Act
    const result = waitingCharge(minutes);
    // Assert: nothing waited -> 0
    assert.strictEqual(result, 0);
  });

  test('charges Rs 10 for every minute beyond 5 on a long wait', () => {
    // Arrange
    const minutes = 15;
    // Act
    const result = waitingCharge(minutes);
    // Assert: (15 - 5) x 10 = 100
    assert.strictEqual(result, 100);
  });
});

describe('R5 - rideSummary', () => {
  test('returns fare, surcharge, waitingCharge and total for normal rides', () => {
    // Arrange
    const rides = [
      { distanceKm: 10, ratePerKm: 25 }, // 250
      { distanceKm: 8, ratePerKm: 30 }, // 240
    ];
    // Act
    const result = rideSummary(rides, 20, 9);
    // Assert: fare = 250 + 240 = 490
    //         surcharge = 490 x 1.20 = 588 -> 588 - 490 = 98
    //         waiting = (9 - 5) x 10 = 40
    //         total = 490 + 98 + 40 = 628
    assert.deepStrictEqual(result, {
      fare: 490,
      surcharge: 98,
      waitingCharge: 40,
      total: 628,
    });
  });

  test('returns all zeros for no rides, and free waiting', () => {
    // Arrange
    const rides = [];
    // Act
    const result = rideSummary(rides, 10, 3);
    // Assert: fare 0, surcharge 0 (0 x 1.10 = 0), waiting 0 (3 <= 5), total 0
    assert.deepStrictEqual(result, {
      fare: 0,
      surcharge: 0,
      waitingCharge: 0,
      total: 0,
    });
  });

  test('computes the surcharge as the rounded extra rupees on top of fare', () => {
    // Arrange
    const rides = [{ distanceKm: 3.8, ratePerKm: 12 }]; // 45.6 -> 46
    // Act
    const result = rideSummary(rides, 15, 6);
    // Assert: fare = 46
    //         surcharge = 46 x 1.15 = 52.9 -> 53 -> 53 - 46 = 7
    //         waiting = (6 - 5) x 10 = 10
    //         total = 46 + 7 + 10 = 63
    assert.deepStrictEqual(result, {
      fare: 46,
      surcharge: 7,
      waitingCharge: 10,
      total: 63,
    });
  });
});

describe('R6 - totalDistance', () => {
  test('adds the distanceKm of every ride', () => {
    // Arrange
    const rides = [
      { distanceKm: 10, ratePerKm: 25 },
      { distanceKm: 2.5, ratePerKm: 12 },
      { distanceKm: 8, ratePerKm: 30 },
    ];
    // Act
    const result = totalDistance(rides);
    // Assert: 10 + 2.5 + 8 = 20.5
    assert.strictEqual(result, 20.5);
  });

  test('returns 0 for an empty list of rides', () => {
    // Arrange
    const rides = [];
    // Act
    const result = totalDistance(rides);
    // Assert: no rides -> 0
    assert.strictEqual(result, 0);
  });

  test('sums distance only and ignores the rate of each ride', () => {
    // Arrange
    const rides = [
      { distanceKm: 4, ratePerKm: 100 },
      { distanceKm: 6, ratePerKm: 1 },
    ];
    // Act
    const result = totalDistance(rides);
    // Assert: 4 + 6 = 10 (rates play no part)
    assert.strictEqual(result, 10);
  });
});
