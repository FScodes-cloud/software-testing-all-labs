// src/taxi.js — Taxi-fare module (Lab Task 04)
// Each function is implemented strictly from its written rule (R1–R6).

// R1: distanceKm × ratePerKm, rounded to the nearest whole rupee.
export function fareForRide(distanceKm, ratePerKm) {
  return Math.round(distanceKm * ratePerKm);
}

// R2: sum of the R1 fare of every ride; an empty list totals 0.
// A ride is an object like { distanceKm: 10, ratePerKm: 25 }.
export function totalFare(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += fareForRide(ride.distanceKm, ride.ratePerKm);
  }
  return sum;
}

// R3: increase amount by percent, rounded to the nearest whole rupee.
export function applyPeakSurcharge(amount, percent) {
  return Math.round((amount * (100 + percent)) / 100);
}

// R4: first 5 minutes are free; every minute beyond 5 costs Rs 10.
export function waitingCharge(minutes) {
  const chargeableMinutes = Math.max(0, minutes - 5);
  return chargeableMinutes * 10;
}

// R5: { fare, surcharge, waitingCharge, total }
export function rideSummary(rides, surchargePercent, minutesWaited) {
  const fare = totalFare(rides);
  const surcharge = applyPeakSurcharge(fare, surchargePercent) - fare;
  const waiting = waitingCharge(minutesWaited);
  return {
    fare,
    surcharge,
    waitingCharge: waiting,
    total: fare + surcharge + waiting,
  };
}

// R6: sum of distanceKm across all rides; an empty list is 0.
export function totalDistance(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += ride.distanceKm;
  }
  return sum;
}
